s = """ abc
def
ghi """

s = """ abc
def '''
ghi
"""

s = ''' abc
def
ghi '''

s = ''' abc
def """
ghi
'''
